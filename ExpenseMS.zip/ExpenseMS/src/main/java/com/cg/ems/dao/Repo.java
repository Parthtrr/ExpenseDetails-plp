package com.cg.ems.dao;

import javax.persistence.EntityManager;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.ems.dto.Expense;
@Repository
@Transactional
public interface Repo extends CrudRepository<Expense, Integer>{


}
