package com.cg.ems;

import static org.hamcrest.CoreMatchers.any;
import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.cg.ems.dao.Repo;
import com.cg.ems.dto.Expense;

@RunWith(SpringRunner.class)
@SpringBootTest
public class EmsApplicationTests {

	
	@Test
	public void contextLoads() {
	}
	
	@Mock
	@Autowired
	Repo repo;
	
	@Spy
	List<Expense> list = new ArrayList<Expense>();
	
	@Captor
	ArgumentCaptor<Expense> captor;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
		list.add(new Expense(102, "Travel", "Imagica"));
		list.add(new Expense(103, "Travel", "Lonavala"));
	}
	
	@Test
	public void addExpense() {
		//create mock
		Expense exp = new Expense(102, "Travel", "Imagica");
		
		// define return value for method save()
		when(repo.save(exp)).thenReturn(exp);
		
		assertEquals(repo.save(exp), exp);
		
	}
	@Test
	public void updateExpense() {
		//create mock
Expense exp = new Expense(102, "Travel", "Imagica");
		
		// define return value for method save()
		when(repo.save(exp)).thenReturn(exp);
		when(repo.findById(102).get()).thenReturn(exp);
		// define return value for method save()
		when(repo.save(exp)).thenReturn(exp);
		
		assertEquals(repo.save(exp), exp);
		
	}

	
}
